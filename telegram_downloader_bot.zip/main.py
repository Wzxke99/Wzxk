
import logging
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = "7996654394:AAGYyEp0jkeQzA0k-8zM7abe_389bnTQhOQ"
CHANNEL_USERNAME = "Wzxw9"

# إعدادات التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# التحقق من الاشتراك
async def is_user_subscribed(user_id: int) -> bool:
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/getChatMember"
    params = {
        "chat_id": f"@{CHANNEL_USERNAME}",
        "user_id": user_id
    }
    response = requests.get(url, params=params).json()
    if response.get("ok"):
        status = response["result"]["status"]
        return status in ["member", "creator", "administrator"]
    return False

# الرد على /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if await is_user_subscribed(user_id):
        await update.message.reply_text("أرسل لي رابط الفيديو من أي منصة (تيك توك، يوتيوب، إنستقرام...) وسأقوم بتحميله لك.")
    else:
        await update.message.reply_text("يجب عليك الاشتراك في قناتنا أولاً:
https://t.me/Wzxw9")

# الرد على أي رسالة تحتوي رابط
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not await is_user_subscribed(user_id):
        await update.message.reply_text("يرجى الاشتراك في القناة أولاً:
https://t.me/Wzxw9")
        return

    url = update.message.text.strip()
    await update.message.reply_text("جارٍ التحميل من الرابط:
" + url + "\n(الميزة ستُفعّل في التحديث القادم).")

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()
